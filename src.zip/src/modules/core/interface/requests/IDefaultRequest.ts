/**
 * Represents the interface for a default request.
 * 
 * @version 1.0.0
 * @since 04/09/23
 * @author
 *  - Devitrax
 */
export interface DefaultRequest {
    url?: string;
}